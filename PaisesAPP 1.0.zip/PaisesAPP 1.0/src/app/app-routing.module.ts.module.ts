import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { PaisComponent } from './paises/pages/pais/pais.component';
import { RegionComponent } from './paises/pages/region/region.component';
import { CapitalComponent } from './paises/pages/capital/capital.component';
import { VerPaisComponent } from './paises/pages/ver-pais/ver-pais.component';



/*conts route vamos a definir todas las rutas
de nuestra app dentro de un arreglo a manera de objeto*/

const routes: Routes = [
  {
    /*path contiene la ruta incial (pagina principal)*/
    path: '',
    component: PaisComponent,
    pathMatch: 'full'
  },
  {
    path: 'region',
    component: RegionComponent
  },
  {
    path: 'capital',
    component: CapitalComponent
  },
  {
    path: 'pais',
    component: PaisComponent
  },
  {
    /*se ponene dos puntos delante del codigo pais
    para que este atributo sea dinamico*/
    path: 'pais/:codigoPais',
    component: VerPaisComponent
  },
  {
    /*En caso que no ingrese una ruta que sea valida
    sera redirigido a la pagina principal (HOME)*/
    path:'**',
    redirectTo: ''
  }
 

];

@NgModule({
  imports: [
    //forRoot ruta principal
    //forchild ruta hija
    RouterModule.forRoot(routes)
  ],
  exports:[
    RouterModule
  ]
})
export class AppRoutingModule{ }
