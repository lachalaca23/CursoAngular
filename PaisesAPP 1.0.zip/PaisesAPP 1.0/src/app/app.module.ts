import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http'

import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { PaisesModule } from './paises/paises.module';
import { SharedModule } from './shared/shared.module';
import { AppRoutingModule } from './app-routing.module.ts.module';






@NgModule({
  declarations: [
    AppComponent,
  ],
  imports: [
    BrowserModule,
    /*Importamos fomrs module para poder utiliza
    twoway data binding [(ngModel)]*/
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    PaisesModule,
    SharedModule
  ],
 
  providers: [],
  bootstrap: [AppComponent]
  
})
export class AppModule { }
