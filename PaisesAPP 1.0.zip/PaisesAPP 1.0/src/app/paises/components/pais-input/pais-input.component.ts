import { Component, EventEmitter, Output, OnInit, Input } from '@angular/core';
import { Subject } from 'rxjs';
import { debounceTime } from 'rxjs/operators';

@Component({
  selector: 'app-pais-input',
  templateUrl: './pais-input.component.html',
  styleUrls: ['./pais-input.component.css']
})
export class PaisInputComponent implements OnInit{
  
  //conectamos (emitimos) el evento a pais.component
  @Output() onEnter: EventEmitter<string> = new EventEmitter();
  //debounce emite cuando la persona deja de escribir
  @Output() onDebounce: EventEmitter<string> = new EventEmitter();

  @Input() placeholder: string = '';

  /*el subject nos permite crear un observable manualmente*/
  debouncer: Subject<string> = new Subject();

  termino: string ='';
  /*se dispara una sola vez cuando inicia la componente
  =====================================================
  pipe() nos devuelve un observable (Operadores rxjs)
  ==================================================
  debounceTime(300) controla las milesimas de segundo
  que se debene esperar maximo para emitir el siguiente
  valor*/
  ngOnInit(){
    this.debouncer
    .pipe(
      debounceTime(400)
    )
    .subscribe(valor =>{
      //emite el valor
      this.onDebounce.emit(valor);
    })
  }

  Buscar(){
    this.onEnter.emit( this.termino );
  }

  teclaPresionada(event: any){
    //referencia al objeto en el cual se lanza el evento
    // const valor = event.target.value;
    //next() - envia el siguiente valor del termino
    this.debouncer.next(this.termino);
  }


}


