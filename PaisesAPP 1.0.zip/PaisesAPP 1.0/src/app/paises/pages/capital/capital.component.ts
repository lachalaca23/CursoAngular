import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Pais } from '../../interfaces/pais-interface';
import { PaisService } from '../../services/pais.service';


@Component({
  selector: 'app-capital',
  templateUrl: './capital.component.html',
  styleUrls: ['./capital.component.css']
})
export class CapitalComponent {

  paises: Pais[] = [];
  termino: string = '';
  hayError: boolean = false;

  constructor(private paisService: PaisService) { }

  Buscar(termino: string){
    this.hayError= false;
    //le asignamos el termino recibido a la
    //propiedad de la clase
    this.termino = termino;

    this.paisService.BuscarCapital(this.termino)
    .subscribe((paises)=>{
      console.log(paises)
      this.paises = paises;
    }, (err) => {
      this.hayError = true;
      this.paises = [];
    });
  }

  Sugerencia(event: string){

  }

  

}
