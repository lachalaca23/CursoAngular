import { Component } from '@angular/core';
import { PaisService } from '../../services/pais.service';
import { Pais } from '../../interfaces/pais-interface';

@Component({
  selector: 'app-pais',
  templateUrl: './pais.component.html',
  styleUrls: ['./pais.component.css']
})
export class PaisComponent {

  termino: string='';
  hayError: boolean = false;

  paises: Pais[] = [];

  //injección del servicio
  constructor(private paisService: PaisService) { }

  Buscar(termino: string){
    this.hayError= false;
    //le asignamos el termino recibido a la
    //propiedad de la clase
    this.termino = termino;

    //para que un observable se capture tenemos que tener
    //un subcribe()
    this.paisService.BuscarPais(this.termino)
    .subscribe( (paises) => {
      console.log(paises)
      this.paises = paises;


    }, (err) => {
      this.hayError = true;
      this.paises = [];

    });

  }

  Sugerencia(termino: string){
    this.hayError = false;
    //crear sugerencias

  }



 

}
