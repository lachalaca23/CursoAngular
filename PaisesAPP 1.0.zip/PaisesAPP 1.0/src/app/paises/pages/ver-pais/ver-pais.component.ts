import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { switchMap, tap } from 'rxjs/operators';
import { Logs } from 'selenium-webdriver';
import { Pais } from '../../interfaces/pais-interface';
import { PaisService } from '../../services/pais.service';

@Component({
  selector: 'app-ver-pais',
  templateUrl: './ver-pais.component.html',
  styleUrls: ['./ver-pais.component.css']
})
export class VerPaisComponent implements OnInit {

  //propiedad pais se pone != para evitar el error
  //o para indicar que es un valor opcional o provisional
  //mientras se suministra la data
  public Pais!: Pais;

  constructor( 
    private activatedRoute: ActivatedRoute, 
    private paisService: PaisService ) { }

  ngOnInit(): void {


    this.activatedRoute.params
    .pipe(
      switchMap( (param) => this.paisService.verPais(param.codigoPais)),
      /*Imprime en consola el observable obtenido de swiychMap*/
      tap(console.log)
      )
      .subscribe(pais => {
        console.log(pais);
        this.Pais = pais[0]
      });  
      
      
      }

  }
    /*params es un observable, y nos muestra el id del pais
    con el nombre definido en la ruta(routing)*/
    /*this.activatedRoute.params
  //   .subscribe(({codigoPais}) => {
  //     console.log(codigoPais);

  //     this.paisService.verPais(codigoPais)
  //     .subscribe( pais => {
  //       console.log(pais)
  //     })
  //   })
  // } */
  