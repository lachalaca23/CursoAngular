import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Pais } from '../interfaces/pais-interface';

@Injectable({
  providedIn: 'root'
})
export class PaisService {

  private apiUrl: string = 'https://restcountries.com/v3.1';

  //utilizamos el servicio
  constructor( private http: HttpClient ) { }

  /*Buscar nos devuelve datos Observable de tipo Pais(interface),
  abrimos las llave [] para no tener errores cuando devuelva mas de un dato
  (un arreglo)*/
  BuscarPais( termino: string ): Observable<Pais[]>{
    //contrucción de la url que queremos utilizar
    const url = `${this.apiUrl}/name/${termino}`;

    //petición
    return this.http.get<Pais[]>(url);
    /*Nos retorna un elemento de tipo
    observable*/
  }

  //servicio buscar capital
  BuscarCapital(termino: string): Observable<Pais[]> {

    const url = `${this.apiUrl}/capital/${termino}`
    
    return this.http.get<Pais[]>(url);
  }
  //Ver pais
  verPais(termino: string): Observable<Pais> {

    const url = `${this.apiUrl}/alpha/${termino}`

    
    return this.http.get<Pais>(url);
  }

  buscarRegion(region: string){

  return this.http.get(`${this.apiUrl}/regionalbloc/${region}`)

  }


}


