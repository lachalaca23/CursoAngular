
import { Component, ViewChild, ElementRef } from '@angular/core';
import { GifsService } from '../services/gifs.service';

@Component({
  selector: 'app-busqueda',
  templateUrl: './busqueda.component.html',
  
})
export class BusquedaComponent {

  /*Toma o recupera el valor de la referencia local (#txtBuscar) y lo
  asigna a la variable txtBuscar
  ==============================
  not null operator txtBuscar!: ElementRef se utiliza 
  para indicarle a typescript que el valor no es nulo
  ya que nos muestra un error como posible valor nulo*/
  @ViewChild('txtBuscar') txtBuscar!: ElementRef<HTMLInputElement>;
  
  //Injectamos el servicio
  constructor(private gifsService: GifsService){

  }
  
  
  Buscar(){

    const valor = this.txtBuscar.nativeElement.value;

    //Verificar si un valor esta vacio
    if(valor.trim().length == 0){
      return;
    }
   
    //accedemos a los metodos del servicio
    this.gifsService.buscarGifs( valor );
    this.txtBuscar.nativeElement.value = '';
  }

}
