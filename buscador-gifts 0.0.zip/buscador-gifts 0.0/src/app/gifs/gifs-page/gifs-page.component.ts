import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gifs-page',
  templateUrl: './gifs-page.component.html',

})
export class GifsPageComponent {

  

 

}
