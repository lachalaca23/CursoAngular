import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resultados',
  templateUrl: './resultados.component.html'

})
export class ResultadosComponent {

  constructor() { }

 

}
