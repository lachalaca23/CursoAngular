import { Injectable } from '@angular/core';


/*providedIn nos ayuda a declarar el servicio de manera 
general y nos ahorra definirlos en el modulo*/
@Injectable({
  providedIn: 'root'
})
export class GifsService {
  
  private apikey: string = 'CtbSNZMFPFlbWl1x5KQjtqPOHnE1ema5';
  private _historial: string[] = [];

  get historial(){
    
    return [...this._historial];
  }

  /*query (consulta ya sea a una base de datos
    , arreglo entre otros) en este caso se utiliza
    para insertar un nuevo elemento 
    =========================================
    se unshift para añadir el elemento al inicio
    del arreglo*/
  buscarGifs(query: string = ''){
    
    /*toLocaleLowerCase() devuelve una cadena 
    de minusculas*/
    query = query.trim().toLocaleLowerCase();
    /*En este caso se inserta el elemento
    si no(!) esta incluido(includes() - determina si
    una matriz inlcuye un determinado elemento
    devuelve true o false) en el arreglo*/
    if(!this._historial.includes(query)){
      this._historial.unshift( query );
      this._historial = this._historial.splice(0,10)
    }
    //Para solo mostrar 11 elementos
    
    console.log(this._historial)
  }

  
}
