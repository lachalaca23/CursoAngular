import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MainPageComponent } from './main-page/main-page.component';
import { FormsModule } from '@angular/forms';
import { PersonajesComponent } from './main-page/personajes/personajes.component';
import { AgregarComponent } from './main-page/agregar/agregar.component';
import { DbzService } from './services/dbz.service';



@NgModule({
  declarations: [MainPageComponent, 
    PersonajesComponent, 
    AgregarComponent
  ],
  /*En los imports van los modulos*/
  imports: [
    CommonModule, 
    FormsModule
  ],
  /*En los exports van las componentes*/
  exports:[
    MainPageComponent
  ],
  /*En los providers van los servicios*/
  providers:[
    DbzService
  ]
})
export class DbzModule { }
