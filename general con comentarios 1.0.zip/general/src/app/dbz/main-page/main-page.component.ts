
import { Component } from '@angular/core';
import { Personaje } from '../interfaces/dbz.interface';
import { DbzService } from '../services/dbz.service';

//type Personaje = Personaje;

@Component({
  selector: 'app-main-page',
  templateUrl: './main-page.component.html',
  styleUrls: ['./main-page.component.css']
})
export class MainPageComponent {
  

  nuevo: Personaje={
    nombre: 'Brasil',
    campeonato: 2
  }
 

 /*Sirve Para realizar peticiones ya sea a una base datos, servicio, entre otros
 ================================================================================
 en este caso se esta obteniendo la información del arreglo personajes*/
  // get personajes(): Personaje[]{
  //   return this.dbzService.personajes;
  // }
  // agregarNuevoPersonaje(argumento: Personaje){
  //   /*Sirve para pausar la funcionalidad del codigo como un (break)
  //   sirve para inspeccionar errores en el codigo*/
  //   // debugger;
  //   // this.personajes.push(argumento)
  // }

  // cambiarNombre(event: any){
  //   console.log(event.target.value)
  // }

  /*Instanciamos los servicios - Injection de dependencia*/
  // constructor( private dbzService: DbzService ){

  // }




}
