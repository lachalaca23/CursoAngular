import { Component, Input } from '@angular/core';
import { DbzService } from '../../services/dbz.service';
import { Personaje } from '../../interfaces/dbz.interface';

@Component({
  selector: 'app-personajes',
  templateUrl: './personajes.component.html',
  styleUrls: ['./personajes.component.css']
})
export class PersonajesComponent {
  /*utilizamos @Input para importar propiedades de otras componentes
  */
  // @Input('personajes_1') personajes: any[] = []

  get personajes(){
    return this.dbzService.personajes;
  }
  constructor( private dbzService: DbzService ){

  }

}
