/*Se exporta para que pueda ser utilzada en otros componentes
las interfaces*/

/*Contiene una estructura que utilizamos en la lista*/
export interface Personaje{
    nombre: string;
    campeonato: number;
}