
import { Component, Input } from '@angular/core';
import { Personaje } from '../interfaces/dbz.interface';

//type Personaje = Personaje;

@Component({
  selector: 'app-main-page',
  templateUrl: './main-page.component.html',
  styleUrls: ['./main-page.component.css']
})
export class MainPageComponent {
  

  personajes: Personaje [] = [
    {
      nombre: 'Colombia',
      campeonato: 2 
    },
    {
      nombre: 'Paraguay',
      campeonato: 2
    }
  ];

  nuevo: Personaje={
    nombre: 'Brasil',
    campeonato: 2
  }
 
  agregarNuevoPersonaje(argumento: Personaje){
    this.personajes.push(argumento)
  }

  cambiarNombre(event: any){
    console.log(event.target.value)
  }




}
