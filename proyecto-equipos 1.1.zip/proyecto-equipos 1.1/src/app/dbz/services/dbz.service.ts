/*A diferencia de las clases normales 
en los servicios el decorador es de tipo injectable--
Los servicios nos sirven para injectar datos de otras fuentes
a nuestra app como por ejemplo de una base de datos*/
import { Injectable } from "@angular/core";
import { Personaje } from '../interfaces/dbz.interface';


@Injectable()

export class DbzService{

    /*Utilizamos _ ya que es un estandar utilizado
    para indicar que una propiedad es privada*/
    private _personajes: Personaje [] = [
        {
            nombre: 'Colombia',
            campeonato: 2 
        },
        {
            nombre: 'Paraguay',
            campeonato: 2
        }
    ];
/*Los(...) simbolizan el operador spread el cual hace una copia del arreglo y la 
muestra por aparte*/
    get personajes(){
        return [...this._personajes];
    }

    constructor(){}

    agregarPersonaje( personaje: Personaje ) {
        this._personajes.push( personaje );
    }

}

