
import { Component } from '@angular/core';
import { MenuItem } from 'primeng/api';


@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent {
  
  items: MenuItem[] = [];

  ngOnInit() {
    this.items = [
        {
          label: 'Pipes de Angular',
          icon: 'pi pi-desktop',
          items: [
            {
              label: 'Textos y Fechas',
              icon: 'pi pi-align-center',
              routerLink: '/'
            },
            {
              label: 'Números',
              icon: 'pi pi-hashtag',
              routerLink: 'numeros'    
            },
            {
              label: 'No Comunes',
              icon: 'pi pi-info-circle',
              routerLink: 'no-comunes'     
            }
          ]
        },
        {
          label: 'Pipes personalizados',
          icon: 'pi pi-cog',
          routerLink: 'ordenar'
        }
    ];

  }
}
