

export enum Color{
    azul, rojo, negro
}


export interface Heroe{
    nombre: string;
    vuelta: boolean;
    color: Color
}