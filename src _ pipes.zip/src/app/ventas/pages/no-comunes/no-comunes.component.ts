import { Component } from '@angular/core';
import { interval, timeout } from 'rxjs';

@Component({
  selector: 'app-no-comunes',
  templateUrl: './no-comunes.component.html',
  styleUrls: ['./no-comunes.component.css']
})
export class NoComunesComponent {

  //i18nselect
  nombre: string = 'Susana';
  genero: string = 'femenino';

  invitacionMapa = {
    'masculino': 'invitarlo',
    'femenino': 'invitarla',
  }

  //i18nplural
  clientes: string[] = ['Maria', 'Pedro', 'Jose', 'Erick'];
  clientesMapa = {
    '=0': 'no tenemos ningun cliente esperando',
    '=1': 'tenemos 1 cliente esperando',
    '=2': 'tenemos 2 cliente esperando',
    //se utiiliza # para tomar el valor de clientes.lenght (tamaño)
    'other': 'tenemos # cliente esperando'
  }


  cambiarClientes(){
    this.nombre = 'melissa';
    this.genero = 'Femenino'
  }

  borrarClientes(){
    this.clientes.pop();
  }

  //Key value pipe
  persona = {
    nombre: 'Fernando',
    edad: 23,
    direccion: 'Colombia'
  }


  //Json pipe
  heroe = [
    {
      nombre: 'Superman',
      vuela: true
    },
    {
      nombre: 'Robin',
      vuela: false
    },
    {
      nombre: 'Aquaman',
      vuela: false
    }
  ]


  //Async pipe
  miObservable = interval (1000)

  
  valorPromesa = new Promise((resolve, reject) => {
    
    setTimeout( () => {
      resolve ( 'tenemos data de promesa' );
    }, 3500)

  })
    
}
