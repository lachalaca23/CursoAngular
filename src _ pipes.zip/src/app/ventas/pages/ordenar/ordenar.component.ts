import { Component } from '@angular/core';
import { Color, Heroe } from '../../interfaces/ventas.interfaces';


@Component({
  selector: 'app-ordenar',
  templateUrl: './ordenar.component.html',
  styleUrls: ['./ordenar.component.css']
})
export class OrdenarComponent {

  constructor(){}

  heroes: Heroe[] = [

    {
      nombre: 'Superman',
      vuelta: true,
      color: Color.azul
    },
    {
      nombre: 'Batman',
      vuelta: false,
      color: Color.negro
    },
    {
      nombre: 'Robin',
      vuelta: false,
      color: Color.rojo
    }
  ]

  cambiar(){

  }

}
